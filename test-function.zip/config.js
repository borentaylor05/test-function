exports.functionName = 'test-function';
exports.awsRegion = 'us-east-1';
exports.roleArn = 'arn:aws:iam::123322973314:role/s3-read-only';